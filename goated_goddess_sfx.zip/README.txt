Goated Goddess 1000 - Sound effects (ElevenLabs Sound Effects v2)

28 sounds x 4 takes = 112 files, in sfx/ (matches public/assets/audio/sfx/).
Named by spec ID with a take number: sfx_<id>_<n>.mp3, per the spec's
Implementation section. Numbers are generation order, not ranking.

Pick the best take(s) per sound and renumber the keepers 1..N
(e.g. keep 3 of sfx_reel_stop as _1, _2, _3; keep 1 of sfx_buy as _1).
manifest.csv lists each file's trigger, spec length, generated length,
variants to keep, the audio.ts function it replaces, and its prompt.

Notes
- Files are ElevenLabs' original output: MP3, 44.1 kHz, 128 kbps. Not WAV
  masters; they have not been re-encoded or upsampled.
- ElevenLabs' minimum duration is 0.5 s, so sounds specced under 0.5 s
  (ui_click, ui_hover, toggle_on/off, bet_step, error, page, spin,
  reel_stop, land, ember_low) are ~0.5 s and need trimming.
- sfx_anticipation and sfx_count_loop were generated with loop mode on.
